// environment.ts
export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8089/aquatresor/api',
    apiImagesUrl: 'http://localhost:8089/aquatresor/api/imagespersonnalise'
  };