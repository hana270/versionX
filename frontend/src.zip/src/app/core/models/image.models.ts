export class ImageBassin{
    idImage! : number ;
    name! : string ;
    type !: string ;
    image !: number[] ;

    imagePath!: string;  // Assure-toi que cette propriété existe

}