export interface BassinMetadata {
    archive: boolean;
    quantity: number;
    isFavorite?: boolean;
    dateAjout?: Date;
    dateDerniereModification?: Date;
}
