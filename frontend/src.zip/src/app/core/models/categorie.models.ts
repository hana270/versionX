export class Categorie{
    idCategorie!: number; 
    nomCategorie!: string;
    description!: string;
  selected!: boolean;
}