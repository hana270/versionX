export const environment = {
    production: false,
    apiUrl: 'http://localhost:8087', // API Gateway URL
    aquatresorBasePath: '/api/aquatresor/api', // Base path for aquatresor service
    notificationsBasePath: '/notifications',
    ordersBasePath: '/api/panier',
    usersBasePath: '/users',
    installationsBasePath: '/api/installations',
  }