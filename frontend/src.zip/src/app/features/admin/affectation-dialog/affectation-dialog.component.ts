import { ChangeDetectorRef, Component } from '@angular/core';
import { OrdersService } from '../../../core/services/orders.service';
import { AuthService } from '../../../core/authentication/auth.service';
import { forkJoin, map, Observable } from 'rxjs';
import { InstallationsService } from '../../../core/services/installations.service';
import { InstallerSpecialty, InstallerSpecialtyDisplayNames } from '../../../core/models/installer-specialty.enum';
import { ActivatedRoute, Router } from '@angular/router';

interface SpecialtyOption {
  value: InstallerSpecialty | '';
  displayName: string;
  icon: string; 
}

@Component({
  selector: 'app-affectation-dialog',
  templateUrl: './affectation-dialog.component.html',
  styleUrls: ['./affectation-dialog.component.css']
})
export class AffectationDialogComponent {
  currentStep = 1;
  commande: any;
  commandeDetails: any;
  isLoading = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;
  
  selectedSpecialties: InstallerSpecialty[] = [];
  specialtyInstallersMap: {[specialty: string]: any[]} = {};
  selectedInstallersBySpecialty: {[specialty: string]: any[]} = {};
  selectedInstallers: any[] = [];
  selectedDate: Date | null = null;
  minDate: Date;
  heureDebut: string = '08:00';
  heureFin: string = '12:00'; // Changé à 12:00 pour correspondre à la fin de matinée

  specialties: SpecialtyOption[] = [
    { value: '', displayName: 'Toutes les spécialités', icon: 'handyman' },
    { 
      value: InstallerSpecialty.PLUMBER_OUTDOOR, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.PLUMBER_OUTDOOR],
      icon: 'plumbing' 
    },
    { 
      value: InstallerSpecialty.ELECTRICIAN_LANDSCAPE, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.ELECTRICIAN_LANDSCAPE],
      icon: 'electrical_services' 
    },
    { 
      value: InstallerSpecialty.LANDSCAPER_POOL_DECORATOR, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.LANDSCAPER_POOL_DECORATOR],
      icon: 'water' 
    },
    { 
      value: InstallerSpecialty.WALL_POOL_INSTALLER, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.WALL_POOL_INSTALLER],
      icon: 'wallpaper' 
    },
    { 
      value: InstallerSpecialty.AQUARIUM_TECHNICIAN, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.AQUARIUM_TECHNICIAN],
      icon: 'water_drop' 
    },
    { 
      value: InstallerSpecialty.MASON_POOL_STRUCTURES, 
      displayName: InstallerSpecialtyDisplayNames[InstallerSpecialty.MASON_POOL_STRUCTURES],
      icon: 'construction' 
    }
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private ordersService: OrdersService,
    private installationsService: InstallationsService,
    private cdr: ChangeDetectorRef
  ) {
    this.minDate = new Date();
    this.minDate.setHours(0, 0, 0, 0);
  }

   ngOnInit(): void {
    const commandeId = this.route.snapshot.paramMap.get('id');
    if (commandeId) {
      this.loadCommande(commandeId);
      this.loadCommandeDetails(commandeId);
      this.loadInstallateurs();
    }

    const navigation = this.router.getCurrentNavigation();
    this.successMessage = navigation?.extras?.state?.['successMessage'];
  }

  loadCommande(commandeId: string): void {
    this.isLoading = true;
    this.ordersService.getCommandeById(commandeId).subscribe({
      next: (commande) => {
        this.commande = commande;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Erreur:', err);
        this.errorMessage = 'Impossible de charger la commande';
        this.isLoading = false;
      }
    });
  }

  loadCommandeDetails(commandeId: string): void {
    this.ordersService.getCommandeById(commandeId).subscribe({
      next: (details) => {
        this.commandeDetails = details;
      },
      error: (err) => {
        console.error('Erreur:', err);
      }
    });
  }

  loadInstallateurs(): void {
    this.isLoading = true;
    this.installationsService.getInstallateurs().subscribe({
      next: (installateurs) => {
        this.specialtyInstallersMap = {};
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Erreur:', err);
        this.errorMessage = 'Impossible de charger les installateurs';
        this.isLoading = false;
      }
    });
  }

  onInstallerSelectionChange(): void {
    this.updateSelectedInstallersList();
    this.cdr.detectChanges();
  }

  getSpecialtyIcon(specialtyValue: InstallerSpecialty | ''): string {
    if (!specialtyValue) return 'handyman';
    const specialtyOption = this.specialties.find(s => s.value === specialtyValue);
    return specialtyOption?.icon || 'handyman';
  }

   isDisabled(): boolean {
    if (this.isLoading) {
      return true;
    }

    if (this.currentStep === 1) {
      return !(
        this.selectedInstallers.length > 0 && 
        this.selectedDate && 
        this.isValidTimeSlot() // Appel sans paramètres
      );
    }
    return false;
  }


   isValidTimeSlot(start?: string, end?: string): boolean {
    const startTime = start ? this.parseTime(start) : this.parseTime(this.heureDebut);
    const endTime = end ? this.parseTime(end) : this.parseTime(this.heureFin);
    
    const isMorningSlot = (
      startTime >= this.parseTime('08:00') && 
      endTime <= this.parseTime('12:00')
    );
    
    const isAfternoonSlot = (
      startTime >= this.parseTime('14:00') && 
      endTime <= this.parseTime('18:00')
    );
    
    const noLunchOverlap = !(
      startTime < this.parseTime('14:00') && 
      endTime > this.parseTime('12:00')
    );
    
    return (isMorningSlot || isAfternoonSlot) && noLunchOverlap && (startTime < endTime);
  }

  private parseTime(timeString: string): number {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }

  removeInstaller(specialty: InstallerSpecialty, installer: any): void {
    if (!this.selectedInstallersBySpecialty[specialty]) return;
    
    this.selectedInstallersBySpecialty[specialty] = 
      this.selectedInstallersBySpecialty[specialty].filter(
        i => i.userId !== installer.userId
      );
    
    this.updateSelectedInstallersList();
  }

  updateSelectedInstallersList(): void {
    this.selectedInstallers = [];
    for (const specialty of this.selectedSpecialties) {
      const installers = this.selectedInstallersBySpecialty[specialty] || [];
      installers.forEach(inst => {
        if (!inst.specialite) {
          inst.specialite = specialty;
        }
      });
      this.selectedInstallers.push(...installers);
    }
  }

  trackByInstallerId(index: number, installer: any): number {
    return installer.userId;
  }

  nextStep(): void {
    if (this.currentStep === 1) {
      if (!this.validateTimes()) {
        return;
      }
      
      this.updateSelectedInstallersList();
      if (this.selectedInstallers.length > 0 && this.selectedDate) {
        this.currentStep = 2;
      }
    } else {
      this.affecter();
    }
  }

  filterInstallersBySpecialties(): void {
  this.isLoading = true;
  this.errorMessage = null;
  
  if (this.selectedSpecialties.length === 0) {
    this.isLoading = false;
    return;
  }

  this.specialtyInstallersMap = {};
  this.selectedInstallersBySpecialty = {};
  this.selectedInstallers = [];

  const specialtyRequests = this.selectedSpecialties.map(specialty => 
    this.installationsService.getInstallateursBySpecialty(specialty).pipe(
      map(installateurs => ({ specialty, installateurs }))
    ) // Parenthèse fermante manquante ajoutée ici
  );

  forkJoin(specialtyRequests).subscribe({
    next: (results) => {
      results.forEach(result => {
        const installateursAvecSpecialite = result.installateurs.map(inst => ({
          ...inst,
          specialtyDisplay: this.getSpecialtyDisplayName(inst.specialite),
          username: inst.nom,
          userId: inst.userId,
          specialite: result.specialty
        }));
        
        this.specialtyInstallersMap[result.specialty] = installateursAvecSpecialite;
        this.selectedInstallersBySpecialty[result.specialty] = [];
      });
      
      this.isLoading = false;
      this.cdr.detectChanges();
    },
    error: (err) => {
      console.error('Erreur:', err);
      this.errorMessage = 'Erreur lors du filtrage par spécialités';
      this.isLoading = false;
    }
  });
}

  getSpecialtyDisplayName(specialtyValue: string): string {
    if (!specialtyValue) return 'Non spécifiée';
    const specialty = this.specialties.find(s => s.value === specialtyValue);
    return specialty ? specialty.displayName : specialtyValue;
  }

 validateTimes(): boolean {
    if (!this.heureDebut || !this.heureFin) {
      this.errorMessage = 'Veuillez sélectionner une heure de début et de fin';
      return false;
    }

    if (!this.isValidTimeSlot()) { // Appel sans paramètres
      this.errorMessage = 'Les créneaux valides sont: 8h-12h (matin) ou 14h-18h (après-midi)';
      return false;
    }

    return true;
  }

  affecter(): void {
    if (!this.selectedDate) {
      this.errorMessage = 'Veuillez sélectionner une date';
      return;
    }

    if (!this.validateTimes()) {
      return;
    }

    this.updateSelectedInstallersList();

    if (this.selectedInstallers.length === 0) {
      this.errorMessage = 'Aucun installateur sélectionné';
      return;
    }

    this.isLoading = true;
    
    const affectationData = {
      installateursIds: this.selectedInstallers.map(i => i.userId),
      commandeId: this.commande.id,
      dateInstallation: this.selectedDate.toISOString().split('T')[0],
      heureDebut: this.heureDebut,
      heureFin: this.heureFin,
      notes: 'Installation programmée'
    };

    this.installationsService.createAffectation(this.commande.id, affectationData).subscribe({
      next: () => {
        this.router.navigate(['/commandes'], {
          state: { successMessage: 'Affectation réussie' }
        });
      },
      error: (err) => {
        console.error('Erreur:', err);
        this.errorMessage = err.message || 'Erreur lors de l\'affectation';
        this.isLoading = false;
      }
    });
  }

  onTimeChange(): void {
    // Si l'heure de début est après 12h, basculer automatiquement sur l'après-midi
    if (this.parseTime(this.heureDebut) >= this.parseTime('12:00') && 
        this.parseTime(this.heureDebut) < this.parseTime('14:00')) {
      this.heureDebut = '14:00';
    }
    
    // Ajuster l'heure de fin si elle est invalide
    if (this.parseTime(this.heureFin) <= this.parseTime(this.heureDebut)) {
      const defaultEnd = this.parseTime(this.heureDebut) < this.parseTime('12:00') 
        ? '12:00' 
        : '18:00';
      this.heureFin = defaultEnd;
    }
  }
}