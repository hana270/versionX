import { Component, Input, HostListener, Output, EventEmitter, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AuthService } from '../../../core/authentication/auth.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css'],
})
export class LayoutComponent implements OnInit, AfterViewInit {
  @Input() pageTitle: string = '';
  @Output() searchQueryChange = new EventEmitter<string>();

  isSidebarOpen: boolean = true;
  isMobile: boolean = false;
  isSearchActive: boolean = false;
  searchQuery: string = '';

  @ViewChild('scrollContainer') scrollContainerRef!: ElementRef;
  @ViewChild('navbar') navbarRef!: ElementRef;

  constructor(private authService: AuthService, private router: Router) {
    this.checkIfMobile();
  }

  ngOnInit() {
    // Restaurer l'état du sidebar
    const savedState = localStorage.getItem('sidebarState');
    if (savedState !== null) {
      this.isSidebarOpen = savedState === 'open';
    }
      
    // Initialiser le conteneur de scroll
    setTimeout(() => {
      this.adjustLayout();
    }, 200);

    // Synchroniser sur les changements de route
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Reset scroll au top à chaque changement de route
        setTimeout(() => {
          const scrollContainer = document.querySelector('.scroll-container');
          if (scrollContainer) {
            scrollContainer.scrollTop = 0;
          }
        }, 100);
      }
    });
  }

  ngAfterViewInit() {
    this.setNavbarHeight();
  }

  private setNavbarHeight() {
    // Définit une hauteur fixe pour la navbar (64px desktop, 56px mobile)
    const navbarHeight = this.isMobile ? 56 : 64;
    document.documentElement.style.setProperty('--navbar-height', `${navbarHeight}px`);
    document.documentElement.style.setProperty('--navbar-height-mobile', `${navbarHeight}px`);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.checkIfMobile();
    this.setNavbarHeight(); // Mettre à jour la hauteur en premier
    this.adjustLayout();    // Puis ajuster le layout
  }

  @HostListener('window:load', ['$event'])
  onWindowLoad(event: any) {
    // S'assurer que le layout est correctement initialisé après le chargement complet
    setTimeout(() => {
      this.setNavbarHeight();
      this.adjustLayout();
    }, 300);
  }

  checkIfMobile() {
    const wasMobile = this.isMobile;
    this.isMobile = window.innerWidth <= 768;
    
    // Si l'état mobile a changé, mettre à jour la hauteur
    if (wasMobile !== this.isMobile) {
      this.setNavbarHeight();
    }
    
    if (this.isMobile && this.isSidebarOpen) {
      this.isSidebarOpen = false;
    }
  }

  adjustLayout() {
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
      
      if (this.scrollContainerRef?.nativeElement) {
        const scrollContainer = this.scrollContainerRef.nativeElement;
        // Utilise la hauteur fixe selon le mode (desktop/mobile)
        const navbarHeight = this.isMobile ? 56 : 64;
        scrollContainer.style.overflowY = 'auto';
        scrollContainer.style.height = `calc(100vh - ${navbarHeight}px)`;
      }
    }, 100);
  }

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
    localStorage.setItem('sidebarState', this.isSidebarOpen ? 'open' : 'closed');
    this.setNavbarHeight(); // Mettre à jour la hauteur en premier
    this.adjustLayout();    // Puis ajuster le layout
  }

  toggleSearch(): void {
    this.isSearchActive = !this.isSearchActive;
    if (!this.isSearchActive) {
      this.searchQuery = '';
      this.onSearchInput();
    }
  }

  onSearchInput(): void {
    this.searchQueryChange.emit(this.searchQuery);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/admin/signin']);
  }
}