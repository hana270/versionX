import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { InstallationsService } from '../../../core/services/installations.service';

@Component({
  selector: 'app-installateur-commandes',
  templateUrl: './installateur-commandes.component.html',
  styleUrls: ['./installateur-commandes.component.css']
})
export class InstallateurCommandesComponent implements OnInit {
  userId!: number;
  commandes: any[] = [];
  isLoading = false;
  errorMessage: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private installationsService: InstallationsService
  ) {}

  ngOnInit(): void {
    this.userId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadCommandes();
  }

  loadCommandes(): void {
    this.isLoading = true;
    this.errorMessage = null;

    // Ici on passe true pour indiquer qu'il s'agit d'un userId
    this.installationsService.getCommandesByInstallateur(this.userId, true).subscribe({
      next: (commandes) => {
        this.commandes = commandes;
        this.isLoading = false;
      },
      error: (err) => {
        this.errorMessage = 'Erreur lors du chargement des commandes';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  getStatusClass(statut: string): string {
    switch(statut) {
      case 'INSTALLATION_EN_COURS':
        return 'badge bg-warning text-dark';
      case 'TERMINEE':
        return 'badge bg-success';
      case 'ANNULEE':
        return 'badge bg-danger';
      default:
        return 'badge bg-secondary';
    }
  }
}