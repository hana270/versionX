import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { InstallationsService } from '../../../core/services/installations.service';
import { Observable } from 'rxjs';
import { AuthService } from '../../../core/authentication/auth.service';

@Component({
  selector: 'app-installer-home',
  templateUrl: './installer-home.component.html',
  styleUrls: ['./installer-home.component.css']
})
export class InstallerHomeComponent {
  constructor(public authService: AuthService) {}

   get userId(): number | null {
    return this.authService.getUserId(); // Utilisez la méthode existante de AuthService
  }
}