import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { CommandeService } from '../../../core/services/commande.service';
import { Commande, StatutCommande } from '../../../core/models/commande.models';

@Component({
  selector: 'app-mes-commandes',
  templateUrl: './mes-commandes.component.html',
  styleUrls: ['./mes-commandes.component.css']
})
export class MesCommandesComponent implements OnInit {
  commandes: Commande[] = [];
  filteredCommandes: Commande[] = [];
  isLoading = false;
  errorMessage: string | null = null;
  clientId: number | null = null;
  selectedStatus = 'tous';
  searchTerm = '';

  constructor(
    private commandeService: CommandeService,
    private authStateService: AuthStateService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadClientIdAndCommandes();
  }

  private loadClientIdAndCommandes(): void {
    const currentUser = this.authStateService.getCurrentUser();
    if (currentUser && currentUser.user_id) {
      this.clientId = currentUser.user_id;
      this.loadCommandes();
    } else {
      this.errorMessage = 'Utilisateur non authentifié. Veuillez vous connecter.';
      this.router.navigate(['/login']);
    }
  }

  private loadCommandes(): void {
    if (!this.clientId) {
      this.errorMessage = 'Identifiant client non disponible.';
      return;
    }

    this.isLoading = true;
    this.errorMessage = null;

    this.commandeService.getCommandesClient(this.clientId).subscribe({
      next: (commandes) => {
        this.commandes = commandes;
        this.filterCommandes();
        this.isLoading = false;
        
        if (commandes.length === 0) {
          this.errorMessage = 'Vous n\'avez pas encore de commandes.';
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.userMessage || 'Une erreur est survenue lors du chargement des commandes.';
        console.error('Erreur chargement commandes:', error);
      }
    });
  }

  filterCommandes(): void {
    this.filteredCommandes = this.commandes.filter(commande => {
      // Filter by status
      const statusMatches = this.selectedStatus === 'tous' || commande.statut.toString() === this.selectedStatus;
      
      // Filter by search term (checks in order number or address)
      const searchTermLower = this.searchTerm.toLowerCase();
      const searchMatches = !this.searchTerm || 
        commande.numeroCommande.toLowerCase().includes(searchTermLower) ||
        commande.adresseLivraison.toLowerCase().includes(searchTermLower) ||
        commande.ville.toLowerCase().includes(searchTermLower) ||
        commande.codePostal.toLowerCase().includes(searchTermLower);
      
      return statusMatches && searchMatches;
    });
  }

  resetFilters(): void {
    this.selectedStatus = 'tous';
    this.searchTerm = '';
    this.filterCommandes();
  }

  getStatusLabel(statut: StatutCommande): string {
    const statusLabels: { [key in StatutCommande]: string } = {
      [StatutCommande.EN_ATTENTE]: 'En attente',
      [StatutCommande.VALIDEE]: 'Validée',
      [StatutCommande.EN_PREPARATION]: 'En préparation',
      [StatutCommande.AFFECTER]: 'Affectée',
      [StatutCommande.EXPEDIEE]: 'Expédiée',
      [StatutCommande.LIVREE]: 'Livrée',
      [StatutCommande.ANNULEE]: 'Annulée',
      [StatutCommande.INSTALLATION_TERMINEE]: 'Installation terminée'
    };
    
    return statusLabels[statut] || statut;
  }

  getStatusClass(statut: StatutCommande): string {
    const statusClasses: { [key in StatutCommande]: string } = {
      [StatutCommande.EN_ATTENTE]: 'badge-warning',
      [StatutCommande.VALIDEE]: 'badge-primary',
      [StatutCommande.EN_PREPARATION]: 'badge-info',
      [StatutCommande.AFFECTER]: 'badge-secondary',
      [StatutCommande.EXPEDIEE]: 'badge-info',
      [StatutCommande.LIVREE]: 'badge-success',
      [StatutCommande.ANNULEE]: 'badge-danger',
      [StatutCommande.INSTALLATION_TERMINEE]: 'badge-success'
    };
    
    return statusClasses[statut] || 'badge-secondary';
  }

  viewCommandeDetails(numeroCommande: string): void {
    this.router.navigate(['/commande', numeroCommande]);
  }

 formatDate(date: Date | null): string {
  if (!date) return 'Date inconnue';
  return new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
}

}